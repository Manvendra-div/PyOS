from tkinter import  *
root=Tk()
img=PhotoImage(file="assets//img//1596529396502.png")
lbl=Label(root,image=img)
lbl.place(x=0,y=0)
btnbt=Button(root,text='BT',height=2,width=2,bd=2)
btnbt.place(x=100,y=0)
root.mainloop()